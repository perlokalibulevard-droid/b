// Translation utilities for Albanian/English support

export const translations = {
  sq: {
    // Header
    title: "Boulevard Cafe",
    subtitle: "Elbasan",
    
    // Main buttons
    visitWebsite: "Vizitoni Faqen Tonë Kryesore / CALL WAITER",
    barCafe: "Bar-Kafe",
    kitchen: "Guzhine",
    
    // Categories - Bar-Kafe
    alcoholicDrinks: "Alkolike & Vodka & Amaro",
    coldDrinks: "Bevande Frede",
    beer: "Birra",
    coffee: "Caffeteria",
    cocktails: "Coctailes",
    wine: "Vinoteca",
    
    // Categories - Kitchen
    appetizers: "Antipastat",
    breakfast: "Mengjesi",
    fingerFood: "Finger Food Chicken",
    pizza: "Pizza",
    
    // Admin Panel
    adminPanel: "Admin Panel",
    password: "Fjalëkalimi",
    passwordPlaceholder: "Shkruani fjalëkalimin...",
    login: "Hyr",
    cancel: "Anulo",
    logout: "Dil",
    close: "Mbyll",
    menuManagement: "Menaxhimi i Menusë",
    category: "Kategoria",
    subcategory: "Nën-kategoria",
    selectCategory: "Zgjidhni kategorinë",
    selectSubcategory: "Zgjidhni nën-kategorinë",
    addNewProduct: "Shto Produkt të Ri",
    products: "produkte",
    
    // Language
    language: "Gjuha",
    albanian: "Shqip",
    english: "English"
  },
  
  en: {
    // Header
    title: "Boulevard Cafe",
    subtitle: "Elbasan",
    
    // Main buttons
    visitWebsite: "Visit Our Main Website / CALL WAITER",
    barCafe: "Bar-Cafe",
    kitchen: "Kitchen",
    
    // Categories - Bar-Cafe
    alcoholicDrinks: "Alcoholic & Vodka & Amaro",
    coldDrinks: "Cold Beverages",
    beer: "Beer",
    coffee: "Coffee Shop",
    cocktails: "Cocktails",
    wine: "Wine Bar",
    
    // Categories - Kitchen
    appetizers: "Appetizers",
    breakfast: "Breakfast",
    fingerFood: "Finger Food Chicken",
    pizza: "Pizza",
    
    // Admin Panel
    adminPanel: "Admin Panel",
    password: "Password",
    passwordPlaceholder: "Enter password...",
    login: "Login",
    cancel: "Cancel",
    logout: "Logout",
    close: "Close",
    menuManagement: "Menu Management",
    category: "Category",
    subcategory: "Subcategory",
    selectCategory: "Select category",
    selectSubcategory: "Select subcategory",
    addNewProduct: "Add New Product",
    products: "products",
    
    // Language
    language: "Language",
    albanian: "Shqip",
    english: "English"
  }
}

export const categoryMapping = {
  sq: {
    "Bar-Kafe": {
      "Alkolike & Vodka & Amaro": "Alkolike & Vodka & Amaro",
      "Bevande Frede": "Bevande Frede", 
      "Birra": "Birra",
      "Caffeteria": "Caffeteria",
      "Coctailes": "Coctailes",
      "Vinoteca": "Vinoteca"
    },
    "Guzhine": {
      "Antipastat": "Antipastat",
      "Mengjesi": "Mengjesi",
      "Finger Food Chicken": "Finger Food Chicken",
      "Pizza": "Pizza"
    }
  },
  en: {
    "Bar-Cafe": {
      "Alcoholic & Vodka & Amaro": "Alkolike & Vodka & Amaro",
      "Cold Beverages": "Bevande Frede",
      "Beer": "Birra", 
      "Coffee Shop": "Caffeteria",
      "Cocktails": "Coctailes",
      "Wine Bar": "Vinoteca"
    },
    "Kitchen": {
      "Appetizers": "Antipastat",
      "Breakfast": "Mengjesi",
      "Finger Food Chicken": "Finger Food Chicken",
      "Pizza": "Pizza"
    }
  }
}

export const getCategoryIcon = (category, language = 'sq') => {
  const categoryKey = language === 'en' ? 
    (category === 'Bar-Cafe' ? 'Bar-Kafe' : 'Guzhine') : 
    category;
    
  const icons = {
    'Alkolike & Vodka & Amaro': '🍸',
    'Bevande Frede': '🥤', 
    'Birra': '🍺',
    'Caffeteria': '☕',
    'Coctailes': '🍹',
    'Vinoteca': '🍷',
    'Antipastat': '🥗',
    'Mengjesi': '🍳',
    'Finger Food Chicken': '🍗',
    'Pizza': '🍕'
  };
  
  return icons[category] || '🍽️';
}

