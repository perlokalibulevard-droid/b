from flask import Blueprint, request, jsonify, session
from functools import wraps
import json
import os

menu_bp = Blueprint('menu', __name__)

# Admin password
ADMIN_PASSWORD = "1983"

# Menu data file path
MENU_DATA_FILE = os.path.join(os.path.dirname(__file__), '..', 'data', 'menu_data.json')

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_authenticated'):
            return jsonify({'error': 'Admin authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function

def load_menu_data():
    """Load menu data from JSON file"""
    try:
        with open(MENU_DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        # Return default menu data if file doesn't exist
        return {
            "Bar-Kafe": {
                "Caffeteria": [
                    {"name": "CAJ I NXEHTE", "price": 70},
                    {"name": "CAJ I NXEHTE BIO", "price": 100},
                    {"name": "COKOLLATE", "price": 150},
                    {"name": "KAFE Amerikane", "price": 100},
                    {"name": "KAFE Dekafeinato", "price": 100},
                    {"name": "KAFE expr", "price": 70},
                    {"name": "KAFE Korreto", "price": 150},
                    {"name": "KAFE Late", "price": 100},
                    {"name": "KAFE Lece-Lece", "price": 120},
                    {"name": "KAFE MAKIATO", "price": 70},
                    {"name": "KAKAO", "price": 150},
                    {"name": "KAPUCHINO ME KAFE", "price": 150},
                    {"name": "SALEP", "price": 100}
                ],
                "Bevande Frede": [
                    {"name": "B52", "price": 170},
                    {"name": "BITER", "price": 100},
                    {"name": "BRAVO", "price": 150},
                    {"name": "COCA-COLA", "price": 150},
                    {"name": "COKOLLATE E FTOHTE", "price": 150},
                    {"name": "CRODINO", "price": 150},
                    {"name": "FANTA", "price": 150},
                    {"name": "FRESH ICE TEA", "price": 200},
                    {"name": "ICE-TEA", "price": 150},
                    {"name": "IVI", "price": 150},
                    {"name": "KAKAO I FTOHTE", "price": 150},
                    {"name": "KAPUCINO E FTOHTE", "price": 150},
                    {"name": "LEMON-SODA", "price": 150},
                    {"name": "LENG FRUTASH NATYRAL", "price": 200},
                    {"name": "LENG PORTOKALLI", "price": 200},
                    {"name": "NESKAFE KANACE", "price": 150},
                    {"name": "PEPSI", "price": 150},
                    {"name": "RED-BULL", "price": 250},
                    {"name": "ROSE", "price": 400},
                    {"name": "TONIK", "price": 150},
                    {"name": "UJE", "price": 70},
                    {"name": "UJE VITAMINA", "price": 120}
                ],
                "Birra": [
                    {"name": "BIRRE PA ALKOL", "price": 250},
                    {"name": "BUDWEISER", "price": 250},
                    {"name": "Heineken Ita 660ml", "price": 420},
                    {"name": "HEINEKEN SHISHE 400ml", "price": 250},
                    {"name": "KORONA", "price": 300},
                    {"name": "KRIKO GOTE 400ml", "price": 220},
                    {"name": "PAULANER", "price": 300},
                    {"name": "PAULANER KRISTAL", "price": 350}
                ],
                "Alkolike & Vodka & Amaro": [
                    {"name": "ABSOLUT", "price": 300},
                    {"name": "DISARONO", "price": 250},
                    {"name": "FERRNET BRANKA", "price": 250},
                    {"name": "JAGERMASTER", "price": 250},
                    {"name": "MONTENEGRO", "price": 250},
                    {"name": "VEKIA ROMANIA", "price": 250},
                    {"name": "VODKA", "price": 300},
                    {"name": "XHIN GORDONS", "price": 250},
                    {"name": "XHIN HINDRICKS", "price": 600},
                    {"name": "BAKARDI", "price": 250},
                    {"name": "BALLATINES", "price": 250},
                    {"name": "CAMPARI", "price": 200},
                    {"name": "CHIVAS", "price": 350},
                    {"name": "JACK DANIELS", "price": 350},
                    {"name": "JB", "price": 250},
                    {"name": "JONNY WALKER", "price": 300},
                    {"name": "JONNY WALKER BLACK", "price": 350},
                    {"name": "METAKSA 5", "price": 300},
                    {"name": "RAKI", "price": 100},
                    {"name": "SANBUKA", "price": 250},
                    {"name": "SHOOTS", "price": 300},
                    {"name": "TEQUILA", "price": 300}
                ],
                "Vinoteca": [
                    {"name": "GOTE VERE", "price": 180},
                    {"name": "GRECO DI TUFO", "price": 2000},
                    {"name": "Luna-M Abruzzo", "price": 2000},
                    {"name": "PAPALE", "price": 5000},
                    {"name": "PINOT GRIGIO", "price": 2000},
                    {"name": "RINFORZO", "price": 2800},
                    {"name": "VERE 1L", "price": 900},
                    {"name": "VERE 375ml", "price": 700},
                    {"name": "VERE E HAPUR 0.5L", "price": 500}
                ],
                "Coctailes": [
                    {"name": "A.M.F", "price": 700},
                    {"name": "Aperol Sprizzz", "price": 500},
                    {"name": "Caipirinha", "price": 500},
                    {"name": "Mohito", "price": 500},
                    {"name": "Tequila Sunrise", "price": 500},
                    {"name": "VODKA SOUR", "price": 500}
                ]
            },
            "Guzhine": {
                "Antipastat": [
                    {"name": "Antipast E NGROHTE", "price": 1000},
                    {"name": "Antipast Mix Djathe", "price": 700},
                    {"name": "Antipast Mix E Ftohte", "price": 800},
                    {"name": "Antipaste Mix Proshut", "price": 700}
                ],
                "Mengjesi": [
                    {"name": "Briosh.", "price": 60},
                    {"name": "Tost Mengjesi", "price": 130}
                ],
                "Finger Food Chicken": [
                    {"name": "Chicken Finger", "price": 600},
                    {"name": "Chicken Wings", "price": 600},
                    {"name": "Gjoks pule i mbushur", "price": 500},
                    {"name": "Grillet Chiken", "price": 600},
                    {"name": "Mix Salcice Zgare", "price": 1000},
                    {"name": "Fried Potatoes", "price": 150}
                ],
                "Pizza": [
                    {"name": "Pizza 4 Djatherat", "price": 500},
                    {"name": "Pizza Cotto Kerpurdhe", "price": 500},
                    {"name": "Pizza Kapricoza", "price": 500},
                    {"name": "Pizza Margarita", "price": 400},
                    {"name": "Pizza Proshut Sallam", "price": 500},
                    {"name": "Pizza Sallam Pikant", "price": 500},
                    {"name": "Pizza Tono", "price": 500},
                    {"name": "Club Sanduic", "price": 200},
                    {"name": "Fokace Brusketa", "price": 300},
                    {"name": "Kalcone M", "price": 500},
                    {"name": "Kalcone V", "price": 300}
                ]
            }
        }

def save_menu_data(data):
    """Save menu data to JSON file"""
    os.makedirs(os.path.dirname(MENU_DATA_FILE), exist_ok=True)
    with open(MENU_DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

@menu_bp.route('/login', methods=['POST'])
def admin_login():
    """Admin login endpoint"""
    data = request.get_json()
    password = data.get('password')
    
    if password == ADMIN_PASSWORD:
        session['admin_authenticated'] = True
        return jsonify({'success': True, 'message': 'Login successful'})
    else:
        return jsonify({'success': False, 'message': 'Invalid password'}), 401

@menu_bp.route('/logout', methods=['POST'])
def admin_logout():
    """Admin logout endpoint"""
    session.pop('admin_authenticated', None)
    return jsonify({'success': True, 'message': 'Logout successful'})

@menu_bp.route('/check-auth', methods=['GET'])
def check_auth():
    """Check if admin is authenticated"""
    return jsonify({'authenticated': session.get('admin_authenticated', False)})

@menu_bp.route('/menu', methods=['GET'])
def get_menu():
    """Get complete menu data"""
    return jsonify(load_menu_data())

@menu_bp.route('/menu/<category>/<subcategory>', methods=['GET'])
def get_subcategory(category, subcategory):
    """Get specific subcategory items"""
    menu_data = load_menu_data()
    if category in menu_data and subcategory in menu_data[category]:
        return jsonify(menu_data[category][subcategory])
    return jsonify({'error': 'Category or subcategory not found'}), 404

@menu_bp.route('/menu/<category>/<subcategory>', methods=['POST'])
@admin_required
def add_item(category, subcategory):
    """Add new item to subcategory"""
    data = request.get_json()
    name = data.get('name')
    price = data.get('price')
    
    if not name or price is None:
        return jsonify({'error': 'Name and price are required'}), 400
    
    menu_data = load_menu_data()
    
    if category not in menu_data:
        menu_data[category] = {}
    if subcategory not in menu_data[category]:
        menu_data[category][subcategory] = []
    
    new_item = {'name': name, 'price': int(price)}
    menu_data[category][subcategory].append(new_item)
    
    save_menu_data(menu_data)
    return jsonify({'success': True, 'item': new_item})

@menu_bp.route('/menu/<category>/<subcategory>/<int:item_index>', methods=['PUT'])
@admin_required
def update_item(category, subcategory, item_index):
    """Update existing item"""
    data = request.get_json()
    name = data.get('name')
    price = data.get('price')
    
    if not name or price is None:
        return jsonify({'error': 'Name and price are required'}), 400
    
    menu_data = load_menu_data()
    
    if (category not in menu_data or 
        subcategory not in menu_data[category] or 
        item_index >= len(menu_data[category][subcategory])):
        return jsonify({'error': 'Item not found'}), 404
    
    menu_data[category][subcategory][item_index] = {'name': name, 'price': int(price)}
    
    save_menu_data(menu_data)
    return jsonify({'success': True, 'item': menu_data[category][subcategory][item_index]})

@menu_bp.route('/menu/<category>/<subcategory>/<int:item_index>', methods=['DELETE'])
@admin_required
def delete_item(category, subcategory, item_index):
    """Delete item"""
    menu_data = load_menu_data()
    
    if (category not in menu_data or 
        subcategory not in menu_data[category] or 
        item_index >= len(menu_data[category][subcategory])):
        return jsonify({'error': 'Item not found'}), 404
    
    deleted_item = menu_data[category][subcategory].pop(item_index)
    
    save_menu_data(menu_data)
    return jsonify({'success': True, 'deleted_item': deleted_item})

