import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Trash2, Edit, Plus, LogOut } from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'
import { translations } from '../utils/translations'

const API_BASE = '/api'

export function AdminPanel({ onClose, onDataUpdate }) {
  const { language } = useLanguage()
  const t = translations[language]
  
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState('')
  const [menuData, setMenuData] = useState({})
  const [selectedCategory, setSelectedCategory] = useState('')
  const [selectedSubcategory, setSelectedSubcategory] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (isAuthenticated) {
      fetchMenuData()
    }
  }, [isAuthenticated])

  const fetchMenuData = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/menu`)
      const data = await response.json()
      setMenuData(data)
    } catch (error) {
      console.error('Error fetching menu data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleLogin = () => {
    if (password === '1983') {
      setIsAuthenticated(true)
      setPassword('')
    } else {
      alert('Incorrect password')
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setSelectedCategory('')
    setSelectedSubcategory('')
    onClose()
  }

  const addProduct = async (name, price) => {
    try {
      const response = await fetch(`${API_BASE}/menu/${selectedCategory}/${selectedSubcategory}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, price: parseFloat(price) })
      })
      
      if (response.ok) {
        await fetchMenuData()
        if (onDataUpdate) onDataUpdate()
      }
    } catch (error) {
      console.error('Error adding product:', error)
    }
  }

  const updateProduct = async (index, name, price) => {
    try {
      const response = await fetch(`${API_BASE}/menu/${selectedCategory}/${selectedSubcategory}/${index}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, price: parseFloat(price) })
      })
      
      if (response.ok) {
        await fetchMenuData()
        if (onDataUpdate) onDataUpdate()
      }
    } catch (error) {
      console.error('Error updating product:', error)
    }
  }

  const deleteProduct = async (index) => {
    try {
      const response = await fetch(`${API_BASE}/menu/${selectedCategory}/${selectedSubcategory}/${index}`, {
        method: 'DELETE'
      })
      
      if (response.ok) {
        await fetchMenuData()
        if (onDataUpdate) onDataUpdate()
      }
    } catch (error) {
      console.error('Error deleting product:', error)
    }
  }

  const getLocalizedCategoryName = (category) => {
    if (language === 'en') {
      return category === 'Bar-Kafe' ? 'Bar-Cafe' : category === 'Guzhine' ? 'Kitchen' : category
    }
    return category
  }

  const getLocalizedSubcategoryName = (subcategory) => {
    const mapping = {
      'sq': {
        'Alkolike & Vodka & Amaro': 'Alkolike & Vodka & Amaro',
        'Bevande Frede': 'Bevande Frede',
        'Birra': 'Birra',
        'Caffeteria': 'Caffeteria',
        'Coctailes': 'Coctailes',
        'Vinoteca': 'Vinoteca',
        'Antipastat': 'Antipastat',
        'Mengjesi': 'Mengjesi',
        'Finger Food Chicken': 'Finger Food Chicken',
        'Pizza': 'Pizza'
      },
      'en': {
        'Alkolike & Vodka & Amaro': 'Alcoholic & Vodka & Amaro',
        'Bevande Frede': 'Cold Beverages',
        'Birra': 'Beer',
        'Caffeteria': 'Coffee Shop',
        'Coctailes': 'Cocktails',
        'Vinoteca': 'Wine Bar',
        'Antipastat': 'Appetizers',
        'Mengjesi': 'Breakfast',
        'Finger Food Chicken': 'Finger Food Chicken',
        'Pizza': 'Pizza'
      }
    }
    return mapping[language][subcategory] || subcategory
  }

  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 backdrop-blur-sm">
        <div className="bg-slate-800 p-8 rounded-lg border border-slate-700 w-96">
          <h2 className="text-2xl font-bold text-amber-400 mb-6 text-center">{t.adminPanel}</h2>
          <div className="space-y-4">
            <div>
              <Label className="text-slate-200">{t.password}</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={t.passwordPlaceholder}
                className="bg-slate-700 border-slate-600 text-white"
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleLogin} className="flex-1 bg-amber-600 hover:bg-amber-700">
                {t.login}
              </Button>
              <Button onClick={onClose} variant="outline" className="flex-1">
                {t.cancel}
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const categories = Object.keys(menuData)
  const subcategories = selectedCategory ? Object.keys(menuData[selectedCategory] || {}) : []
  const items = selectedCategory && selectedSubcategory ? menuData[selectedCategory][selectedSubcategory] || [] : []

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 backdrop-blur-sm p-4">
      <div className="bg-slate-800 rounded-lg border border-slate-700 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-slate-700 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-amber-400">{t.menuManagement}</h2>
          <div className="flex gap-2">
            <Button onClick={handleLogout} variant="outline" size="sm">
              <LogOut className="w-4 h-4 mr-2" />
              {t.logout}
            </Button>
            <Button onClick={onClose} variant="outline" size="sm">
              {t.close}
            </Button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Category and Subcategory Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-200">{t.category}</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="bg-slate-700 border-slate-600">
                  <SelectValue placeholder={t.selectCategory} />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>
                      {getLocalizedCategoryName(category)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-200">{t.subcategory}</Label>
              <Select 
                value={selectedSubcategory} 
                onValueChange={setSelectedSubcategory}
                disabled={!selectedCategory}
              >
                <SelectTrigger className="bg-slate-700 border-slate-600">
                  <SelectValue placeholder={t.selectSubcategory} />
                </SelectTrigger>
                <SelectContent>
                  {subcategories.map(subcategory => (
                    <SelectItem key={subcategory} value={subcategory}>
                      {getLocalizedSubcategoryName(subcategory)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Add New Product */}
          {selectedCategory && selectedSubcategory && (
            <div className="border border-slate-700 rounded-lg p-4">
              <Button 
                onClick={() => {
                  const name = prompt('Product name:')
                  const price = prompt('Product price:')
                  if (name && price) {
                    addProduct(name, price)
                  }
                }}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                {t.addNewProduct}
              </Button>
            </div>
          )}

          {/* Products List */}
          {selectedCategory && selectedSubcategory && (
            <div>
              <h3 className="text-xl font-bold text-amber-400 mb-4">
                {getLocalizedSubcategoryName(selectedSubcategory)} - {items.length} {t.products}
              </h3>
              <div className="space-y-2">
                {items.map((item, index) => (
                  <div key={index} className="flex items-center justify-between bg-slate-700/50 p-3 rounded-lg">
                    <div className="flex-1">
                      <span className="text-white font-medium">{item.name}</span>
                      <span className="text-amber-400 font-bold ml-4">{item.price.toFixed(2)} ALL</span>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const name = prompt('New name:', item.name)
                          const price = prompt('New price:', item.price)
                          if (name && price) {
                            updateProduct(index, name, price)
                          }
                        }}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => {
                          if (confirm('Are you sure you want to delete this item?')) {
                            deleteProduct(index)
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

