import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Coffee, Wine, UtensilsCrossed, ExternalLink, Settings } from 'lucide-react'
import { AdminPanel } from './components/AdminPanel.jsx'
import { LanguageProvider, useLanguage } from './contexts/LanguageContext'
import { LanguageToggle } from './components/LanguageToggle'
import { translations, categoryMapping } from './utils/translations'
import './App.css'

const API_BASE = '/api'

function AppContent() {
  const { language } = useLanguage()
  const t = translations[language]
  
  const [selectedCategory, setSelectedCategory] = useState(language === 'en' ? 'Bar-Cafe' : 'Bar-Kafe')
  const [menuData, setMenuData] = useState({})
  const [loading, setLoading] = useState(true)
  const [showAdmin, setShowAdmin] = useState(false)

  // Update selected category when language changes
  useEffect(() => {
    if (language === 'en') {
      setSelectedCategory(prev => prev === 'Bar-Kafe' ? 'Bar-Cafe' : prev === 'Guzhine' ? 'Kitchen' : prev)
    } else {
      setSelectedCategory(prev => prev === 'Bar-Cafe' ? 'Bar-Kafe' : prev === 'Kitchen' ? 'Guzhine' : prev)
    }
  }, [language])

  const fetchMenuData = async () => {
    try {
      const response = await fetch(`${API_BASE}/menu`)
      const data = await response.json()
      setMenuData(data)
    } catch (error) {
      console.error('Error fetching menu data:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchMenuData()
  }, [])

  const getLocalizedCategoryName = (category) => {
    if (language === 'en') {
      return category === 'Bar-Kafe' ? 'Bar-Cafe' : category === 'Guzhine' ? 'Kitchen' : category
    }
    return category
  }

  const getOriginalCategoryName = (localizedCategory) => {
    if (language === 'en') {
      return localizedCategory === 'Bar-Cafe' ? 'Bar-Kafe' : localizedCategory === 'Kitchen' ? 'Guzhine' : localizedCategory
    }
    return localizedCategory
  }

  const getLocalizedSubcategoryName = (subcategory, category) => {
    const originalCategory = getOriginalCategoryName(category)
    const mapping = categoryMapping[language]
    
    if (mapping && mapping[category]) {
      // Find the localized name by looking for the original subcategory
      for (const [localizedName, originalName] of Object.entries(mapping[category])) {
        if (originalName === subcategory) {
          return localizedName
        }
      }
    }
    return subcategory
  }

  const getCurrentCategoryData = () => {
    const originalCategory = getOriginalCategoryName(selectedCategory)
    return menuData[originalCategory] || {}
  }

  const formatPrice = (price) => {
    const numPrice = parseFloat(price)
    return `${numPrice.toFixed(2).replace('.', ',')} ALL`
  }

  const getCategoryIcon = (category) => {
    const iconMap = {
      'Bar-Kafe': Coffee,
      'Bar-Cafe': Coffee,
      'Guzhine': UtensilsCrossed,
      'Kitchen': UtensilsCrossed
    }
    return iconMap[category] || Coffee
  }

  const getSubcategoryIcon = (subcategory) => {
    const iconMap = {
      'Alkolike & Vodka & Amaro': '🍸',
      'Alcoholic & Vodka & Amaro': '🍸',
      'Bevande Frede': '🥤',
      'Cold Beverages': '🥤',
      'Birra': '🍺',
      'Beer': '🍺',
      'Caffeteria': '☕',
      'Coffee Shop': '☕',
      'Coctailes': '🍹',
      'Cocktails': '🍹',
      'Vinoteca': '🍷',
      'Wine Bar': '🍷',
      'Antipastat': '🥗',
      'Appetizers': '🥗',
      'Mengjesi': '🍳',
      'Breakfast': '🍳',
      'Finger Food Chicken': '🍗',
      'Pizza': '🍕'
    }
    return iconMap[subcategory] || '🍽️'
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-amber-400 text-xl">Loading...</div>
      </div>
    )
  }

  const categoryData = getCurrentCategoryData()
  const subcategories = Object.keys(categoryData)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <LanguageToggle />
      
      {/* Header */}
      <div className="text-center py-8 relative">
        <h1 className="text-6xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent mb-2">
          {t.title}
        </h1>
        <p className="text-xl text-slate-300">{t.subtitle}</p>
        
        {/* Admin Settings Button */}
        <button
          onClick={() => setShowAdmin(true)}
          className="absolute top-4 right-4 p-2 bg-slate-800/50 hover:bg-slate-700/50 rounded-lg transition-colors"
          title="Admin Panel"
        >
          <Settings className="w-5 h-5 text-slate-400 hover:text-amber-400" />
        </button>
      </div>

      {/* Main Action Button */}
      <div className="flex justify-center mb-8">
        <Button 
          className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-black font-bold text-lg px-8 py-4 rounded-full shadow-lg transform hover:scale-105 transition-all duration-200"
        >
            <a href="https://3dhkilc8q71z.manus.space/?table=Qe+Mori+Scan+Menu" target="_blank" rel="noopener noreferrer" className="flex items-center">
            <ExternalLink className="w-5 h-5 mr-2" />
            {t.visitWebsite}
          </a>
        </Button>
      </div>

      {/* Category Selector */}
      <div className="flex justify-center mb-8">
        <div className="flex bg-slate-800/50 rounded-full p-1 backdrop-blur-sm border border-slate-700/50">
          {[
            { key: language === 'en' ? 'Bar-Cafe' : 'Bar-Kafe', label: t.barCafe, icon: Coffee },
            { key: language === 'en' ? 'Kitchen' : 'Guzhine', label: t.kitchen, icon: UtensilsCrossed }
          ].map(({ key, label, icon: Icon }) => (
            <Button
              key={key}
              onClick={() => setSelectedCategory(key)}
              className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all duration-200 ${
                selectedCategory === key
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold shadow-lg'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <Icon className="w-5 h-5" />
              {label}
            </Button>
          ))}
        </div>
      </div>

      {/* Subcategory Tabs */}
      <div className="flex justify-center mb-8 px-4">
        <div className="flex flex-wrap gap-2 max-w-4xl justify-center">
          {subcategories.map((subcategory) => {
            const localizedName = getLocalizedSubcategoryName(subcategory, selectedCategory)
            const icon = getSubcategoryIcon(localizedName)
            return (
              <Badge
                key={subcategory}
                className="bg-slate-700/50 hover:bg-slate-600/50 text-slate-200 px-4 py-2 cursor-pointer transition-all duration-200 border border-slate-600/50 hover:border-amber-500/50"
              >
                <span className="mr-2">{icon}</span>
                {localizedName}
              </Badge>
            )
          })}
        </div>
      </div>

      {/* Menu Items */}
      <div className="max-w-7xl mx-auto px-4 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subcategories.map((subcategory) => {
            const items = categoryData[subcategory] || []
            const localizedName = getLocalizedSubcategoryName(subcategory, selectedCategory)
            const icon = getSubcategoryIcon(localizedName)
            
            return (
              <Card key={subcategory} className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm hover:bg-slate-800/70 transition-all duration-200">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-amber-400 mb-4 flex items-center gap-2">
                    <span className="text-2xl">{icon}</span>
                    {localizedName}
                  </h3>
                  <div className="space-y-3">
                    {items.map((item, index) => (
                      <div key={index} className="flex justify-between items-center py-2 border-b border-slate-700/30 last:border-b-0">
                        <span className="text-slate-200 font-medium">{item.name}</span>
                        <span className="text-amber-400 font-bold">{formatPrice(item.price)}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Admin Panel */}
      {showAdmin && (
        <AdminPanel onClose={() => setShowAdmin(false)} onDataUpdate={fetchMenuData} />
      )}
    </div>
  )
}

function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  )
}

export default App

