# Boulevard Cafe Elbasan - Web Application

A modern web application for Boulevard Cafe Elbasan featuring:

- **Multi-language support** (Albanian/English)
- **Menu management system** with admin panel
- **Responsive design** for all devices
- **Real-time menu updates** via admin interface
- **Modern UI/UX** with dark theme and animations

## Features

### Frontend
- React.js with Tailwind CSS
- Multi-language toggle (Albanian ↔ English)
- Responsive design for desktop and mobile
- Modern dark theme with amber accents
- Smooth animations and transitions

### Backend
- Flask API with CORS support
- SQLite database for menu storage
- Admin authentication (password: 1983)
- RESTful API endpoints for menu management

### Admin Panel
- Secure password-protected access
- Add, edit, and delete menu items
- Category and subcategory management
- Real-time price updates

## Deployment

This application is configured for deployment on Render.com with:
- Gunicorn WSGI server
- Automatic builds from Git repository
- Environment configuration via render.yaml

## Local Development

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   python src/main.py
   ```

3. Access the application at `http://localhost:5000`

## Admin Access

- Click the settings icon (⚙️) in the top-right corner
- Enter password: **1983**
- Select category and subcategory to manage menu items

## API Endpoints

- `GET /api/menu` - Get all menu data
- `POST /api/menu/<category>/<subcategory>` - Add new menu item
- `PUT /api/menu/<category>/<subcategory>/<index>` - Update menu item
- `DELETE /api/menu/<category>/<subcategory>/<index>` - Delete menu item

## Technologies Used

- **Frontend**: React, Tailwind CSS, Lucide Icons
- **Backend**: Flask, SQLAlchemy, Flask-CORS
- **Database**: SQLite
- **Deployment**: Render.com, Gunicorn

