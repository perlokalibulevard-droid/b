# Boulevard Cafe Elbasan - Design Concept

## Project Overview
Modern web application for Boulevard Cafe Elbasan featuring:
- Menu display with two main categories: Bar-Kafe and Guzhine
- Admin panel with password authentication (1983)
- Responsive design for all devices
- Prominent button linking to external site

## Visual Style

### Color Palette
- **Primary Dark**: #1a1a1a (Deep charcoal)
- **Secondary Dark**: #2d2d2d (Medium charcoal)
- **Accent Gold**: #d4af37 (Elegant gold)
- **Accent Warm**: #8b4513 (Warm brown)
- **Text Light**: #f5f5f5 (Off-white)
- **Text Secondary**: #cccccc (Light gray)

### Typography
- **Headings**: Playfair Display (elegant serif)
- **Body Text**: Inter (modern sans-serif)
- **Menu Items**: Roboto (clean, readable)

### Layout Principles
- Dark, sophisticated background
- Warm accent lighting effects
- Clean typography hierarchy
- Generous white space
- Mobile-first responsive design

## Website Structure

### Main Categories
1. **Bar-Kafe**
   - Caffeteria
   - Bevande Frede
   - Birra
   - Alkolike & Vodka & Amaro
   - Vinoteca
   - Coctailes

2. **Guzhine**
   - Antipastat
   - Mengjesi
   - Finger Food Chicken
   - Pizza

### Key Features
- Category-based navigation
- Subcategory filtering
- Price display in ALL currency
- Admin authentication system
- Product management interface
- Prominent external link button

## Technical Specifications
- React.js frontend
- Flask backend
- Responsive CSS Grid/Flexbox
- Modern JavaScript ES6+
- Local storage for admin session
- RESTful API for CRUD operations

## User Experience
- Intuitive navigation between categories
- Quick subcategory access
- Clean menu presentation
- Easy admin access for updates
- Mobile-optimized interface

