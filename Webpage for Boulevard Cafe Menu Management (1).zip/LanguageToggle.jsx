import React from 'react'
import { Globe } from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'
import { translations } from '../utils/translations'

export const LanguageToggle = () => {
  const { language, toggleLanguage } = useLanguage()
  const t = translations[language]

  return (
    <div className="fixed top-4 left-4 z-50">
      <button
        onClick={toggleLanguage}
        className="flex items-center gap-2 bg-slate-800/90 hover:bg-slate-700/90 text-white px-3 py-2 rounded-lg backdrop-blur-sm transition-all duration-200 border border-slate-600/50 hover:border-amber-500/50"
        title={t.language}
      >
        <Globe className="w-4 h-4" />
        <span className="text-sm font-medium">
          {language === 'sq' ? 'EN' : 'SQ'}
        </span>
      </button>
    </div>
  )
}

